.. :changelog:

History
-------


0.14.0 - (2015-12-09)
---------------------

* update project structure
* remove setuptools from requirements


0.13.8 - (2015-04-12)
---------------------

* fix scatterChart


0.13.7 - (2015-04-06)
---------------------

* set format on x2Axis for focus


0.13.6 - (2015-04-06)
---------------------

* add support for focusEnable

* remove linePlusBarWithFocusChart as this is replaced by linePlusBarChart with option FocusEnable():
  http://nvd3-community.github.io/nvd3/examples/documentation.html#linePlusBarChart

* Sourcing JS assets over https when appropriate


0.13.5 (2014-11-13)
-------------------

* Fix: color_list extra arguments is not mandatory on piechart


0.13.0 (2014-08-04)
-------------------

* User Jinja2 to create the JS charts


0.11.0 (2013-10-09)
-------------------

* allow chart_attr to be set as follow 'xAxis': '.rotateLabels(-25)'
  this will turn into calling chart.xAxis.rotateLabels(-25)


0.11.0 (2013-10-09)
-------------------

* date setting is replaced by x_is_date
* refactoring


0.10.2 (2013-10-04)
-------------------

* discreteBarChart support date on xAxis


0.10.1 (2013-10-03)
-------------------

* Remove $ sign in linePlusBarWithFocusChart


0.10.0 (2013-10-02)
------------------

* Support new chart linePlusBarWithFocusChart


0.9.0 (2013-09-30)
------------------

* Use Bower to install D3 and NVD3


0.8.0 (2013-08-15)
------------------

* add NVD3Chart.buildcontent() by cmorgan (Chris Morgan)
* Add show_labels parameter for Piechart by RaD (Ruslan Popov)


0.7.0 (2013-07-09)
------------------

* Generalise the axis_formatting & add support for hiding the legend by nzjrs (John Stowers)
* Fix #7 from DanMeakin, wrong str conversion of x-axis dates


0.6.0 (2013-06-05)
------------------

* Add AM_PM function for x-axis on lineChart


0.5.2 (2013-05-31)
------------------

* ScatterChat option to pass 'size': '10' as argument of the series
* Fix in setup.py for python3


0.5.1 (2013-05-30)
------------------

* Fix multiChart with date


0.5.0 (2013-05-28)
------------------

* Add color_list option on piechart


0.4.1 (2013-05-06)
------------------

* Fix removed forced sorted on x-axis


0.4.0 (2013-04-28)
------------------

* Add support for Python3


0.3.6 (2013-04-24)
------------------

* Add custom dateformat var for tooltip


0.3.5 (2013-04-23)
------------------

* Fix style


0.3.4 (2013-04-23)
------------------

* Support for px and % on height and width
* Add tag_script_js property to disable tag <script>


0.3.3 (2013-04-23)
------------------

* Data series it now in javascript format


0.3.2 (2013-04-22)
------------------

* Fix lineChart tooltip


0.3.1 (2013-04-19)
------------------

* Option to change the color schemes
* Set a specific color per serie


0.3 (2013-04-19)
----------------

* Add tooltip support
* Mix enhancement of APIs


0.2 (2013-04-16)
----------------

* Proper project release including support for the following chart:

    lineWithFocusChart
    lineChart
    multiBarChart
    pieChart
    stackedAreaChart
    multiBarHorizontalChart
    linePlusBarChart
    cumulativeLineChart
    discreteBarChart
    scatterChart


0.1 (2013-04-08)
----------------

* First release
