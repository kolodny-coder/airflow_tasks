.. module:: nvd3.linePlusBarChart

.. _linePlusBarChart-model:

:class:`linePlusBarChart`
-------------------------

.. autoclass:: linePlusBarChart

See the HTML source code of this page, to see the underlying javascript.
