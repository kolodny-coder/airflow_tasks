.. module:: nvd3.discreteBarChart

.. _discreteBarChart-model:

:class:`discreteBarChart`
-------------------------

.. autoclass:: discreteBarChart
    :noindex:

See the HTML source code of this page, to see the underlying javascript.
