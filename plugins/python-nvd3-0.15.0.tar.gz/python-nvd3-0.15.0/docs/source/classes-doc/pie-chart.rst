.. module:: nvd3.pieChart

.. _pieChart-model:

:class:`pieChart`
-----------------

.. autoclass:: pieChart
    :noindex:

See the HTML source code of this page, to see the underlying javascript.

