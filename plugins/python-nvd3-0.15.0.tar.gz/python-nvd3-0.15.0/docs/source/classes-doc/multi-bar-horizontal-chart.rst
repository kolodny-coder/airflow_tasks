.. module:: nvd3.multiBarHorizontalChart

.. _multiBarHorizontalChart-model:

:class:`multiBarHorizontalChart`
--------------------------------
.. autoclass:: multiBarHorizontalChart
    :noindex:

See the HTML source code of this page, to see the underlying javascript.
