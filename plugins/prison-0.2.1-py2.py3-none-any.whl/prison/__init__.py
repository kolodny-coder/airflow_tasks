from .decoder import loads
from .encoder import dumps

__all__ = ['loads', 'dumps']
