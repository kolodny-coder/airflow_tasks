"""
Benchmarks for validation.

This package is *not* public API.
"""
